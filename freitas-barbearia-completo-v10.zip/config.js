window.BARBERSHOP_CONFIG = {
  SUPABASE_URL: "COLE_AQUI_A_URL_DO_PROJETO",
  SUPABASE_PUBLISHABLE_KEY: "COLE_AQUI_A_PUBLISHABLE_KEY",

  USE_SUPABASE_APPOINTMENTS: true,

  SLOT_INTERVAL_MINUTES: 30,

  // Fallback usado somente se os horários do Supabase não puderem ser carregados.
  OPENING_HOURS: {
    0: null,
    1: { open: "09:00", close: "18:00" },
    2: { open: "09:00", close: "18:00" },
    3: { open: "09:00", close: "18:00" },
    4: { open: "09:00", close: "18:00" },
    5: { open: "09:00", close: "18:00" },
    6: { open: "09:00", close: "18:00" }
  }
};
